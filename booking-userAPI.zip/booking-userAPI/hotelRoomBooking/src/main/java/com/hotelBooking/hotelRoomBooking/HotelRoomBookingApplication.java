package com.hotelBooking.hotelRoomBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelRoomBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelRoomBookingApplication.class, args);
		
		
	}

}

